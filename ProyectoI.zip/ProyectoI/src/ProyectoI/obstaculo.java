package ProyectoI;

/**
 *
 * @author Mari
 */
public class obstaculo extends serVivo{

    public obstaculo(int vida, int x, int y, boolean movimiento) {
        super(vida, x, y, movimiento);
    }

}
