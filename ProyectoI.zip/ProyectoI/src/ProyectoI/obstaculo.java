package ProyectoI;

/**
 *
 * @author Mari
 */
public class obstaculo extends serVivo{

    public obstaculo(int vida, int x, int y, boolean movimiento, 
            String posicion, ProcesosTablero tablero) {
        super(vida, x, y, movimiento, posicion, tablero);
    }

    
    
}
