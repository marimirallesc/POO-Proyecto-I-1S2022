package ProyectoI;

/**
 *
 * @author Mari
 */
public class amenaza extends serVivo{

    public amenaza(int vida, int x, int y, boolean movimiento) {
        super(vida, x, y, movimiento);
    }

}
