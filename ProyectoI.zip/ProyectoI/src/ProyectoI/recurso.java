package ProyectoI;

/**
 *
 * @author Mari
 */
public class recurso extends serVivo{

    public recurso(int vida, int x, int y, boolean movimiento, String posicion, ProcesosTablero tablero) {
        super(vida, x, y, movimiento, posicion, tablero);
    }

}
