package ProyectoI;

/**
 *
 * @author Mari
 */
public class recurso extends serVivo{

    public recurso(int vida, int x, int y, boolean movimiento) {
        super(vida, x, y, movimiento);
    }
    
}
